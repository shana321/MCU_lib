#ifndef _HardwareSerial_h_
#define _HardwareSerial_h_

#include "main.h"
#include "STC15F2K60S2.h"

#define AVRAM 1024  //�������ڴ��С����ϵ�����滺������С

#define HAL_PRINTF            0u

#ifndef SERIAL_TX_BUFFER_SIZE
	#if (AVRAM < 1023)
	#define SERIAL_TX_BUFFER_SIZE 16
	#else
	#define SERIAL_TX_BUFFER_SIZE 64
	#endif
#endif

#ifndef SERIAL_RX_BUFFER_SIZE
	#if (AVRAM < 1023)
	#define SERIAL_RX_BUFFER_SIZE 16
	#else
	#define SERIAL_RX_BUFFER_SIZE 64
	#endif
#endif


#if (SERIAL_TX_BUFFER_SIZE>256)
typedef uint16_t tx_buffer_index_t;
#else
typedef uint8_t tx_buffer_index_t;
#endif
#if  (SERIAL_RX_BUFFER_SIZE>256)
typedef uint16_t rx_buffer_index_t;
#else
typedef uint8_t rx_buffer_index_t;
#endif

typedef struct HardwareSerial_struct HardwareSerial_t;
typedef uint8_t (*hard_msg_cb)(HardwareSerial_t *ser,uint8_t msg);
	

#define HSER_MSG_INIT          40
#define HSER_MSG_END           41
#define HSER_MSG_SEND_RI     	 42
#define HSER_MSG_WRITE_TI      43
#define HSER_MSG_EA            44
#define HSER_MSG_ES            45

struct HardwareSerial_struct
{
    volatile bool _written;//���ڱ�ʶ����״̬��true �������ڷ������ݣ�false ���ڿ���

    volatile rx_buffer_index_t _rx_buffer_head;
    volatile rx_buffer_index_t _rx_buffer_tail;
    volatile tx_buffer_index_t _tx_buffer_head;
    volatile tx_buffer_index_t _tx_buffer_tail;

    unsigned char _rx_buffer[SERIAL_RX_BUFFER_SIZE];
    unsigned char _tx_buffer[SERIAL_TX_BUFFER_SIZE];
	
		hard_msg_cb init_end_cb;
		hard_msg_cb hard_send_cb;
		
};


void HardwareSerial_Init(HardwareSerial_t *ser,hard_msg_cb basic_cb,hard_msg_cb send);//�����ʼ��
void HardwareSerial_begin(HardwareSerial_t *ser);//���ڳ�ʼ��
void HardwareSerial_end(HardwareSerial_t *ser);//���ڳ�ʼ��


size_t HardwareSerial_available(HardwareSerial_t *ser);
size_t HardwareSerial_availableForWrite(HardwareSerial_t *ser);


int16_t HardwareSerial_peek(HardwareSerial_t *ser);
int16_t HardwareSerial_read(HardwareSerial_t *ser);
size_t HardwareSerial_write(HardwareSerial_t *ser,uint8_t p_tr);


void HardwareSerial_tx_udr_empty_irq(HardwareSerial_t *ser);
void HardwareSerial_rx_complete_irq(HardwareSerial_t *ser,uint8_t c);



#if HAL_PRINTF > 0
	#define HSER_IT       0
	#define HSER_SOFE     1
void HardwareSerial_printf(HardwareSerial_t *ser,uint8_t ,char* fmt, ...);
#endif


#endif