#include "HardwareSerial.h"

int16_t HardwareSerial_peek(HardwareSerial_t *ser)
{
		if (ser->_rx_buffer_head == ser->_rx_buffer_tail) 
		{
			return -1;
		} 
		else 
		{
			return ser->_rx_buffer[ser->_rx_buffer_tail];
		}
}
int16_t HardwareSerial_read(HardwareSerial_t *ser)
{
  if (ser->_rx_buffer_head == ser->_rx_buffer_tail)
	{
    return -1;
	}
	else
	{
    unsigned char c = ser->_rx_buffer[ser->_rx_buffer_tail];
    ser->_rx_buffer_tail = (rx_buffer_index_t)(ser->_rx_buffer_tail + 1) % SERIAL_RX_BUFFER_SIZE;
    return c;
	}
}
void HardwareSerial_tx_udr_empty_irq(HardwareSerial_t *ser)
{
		unsigned char c = 0;
 // If interrupts are enabled, there must be more data in the output
  // buffer. Send the next byte
	ser->_written = false;
	  if (ser->_tx_buffer_head == ser->_tx_buffer_tail) {
    // Buffer empty, so disable interrupts
    //cbi(*_ucsrb, UDRIE0);
			return;//�������
  }
  c = ser->_tx_buffer[ser->_tx_buffer_tail];
  ser->_tx_buffer_tail = (ser->_tx_buffer_tail + 1) % SERIAL_TX_BUFFER_SIZE;

  ser->hard_send_cb(ser,c);
	ser->_written = true;

	
  // clear the TXC bit -- "can be cleared by writing a one to its bit
  // location". This makes sure flush() won't return until the bytes
  // actually got written
  //sbi(*_ucsra, TXC0);

//  if (_tx_buffer_head == _tx_buffer_tail) {
//    // Buffer empty, so disable interrupts
//    //cbi(*_ucsrb, UDRIE0);
//  }
}
void HardwareSerial_rx_complete_irq(HardwareSerial_t *ser,uint8_t c)
{
	rx_buffer_index_t i = (unsigned int)(ser->_rx_buffer_head + 1) % SERIAL_RX_BUFFER_SIZE;


	
    if (i != ser->_rx_buffer_tail)
		{
      ser->_rx_buffer[ser->_rx_buffer_head] = c;
      ser->_rx_buffer_head = i;
    }
		
}
size_t HardwareSerial_available(HardwareSerial_t *ser)
{
	size_t ret = 0;
	
	ret = ((rx_buffer_index_t)(SERIAL_RX_BUFFER_SIZE + ser->_rx_buffer_head - ser->_rx_buffer_tail)) % SERIAL_RX_BUFFER_SIZE;
	
  return ret;
}
size_t HardwareSerial_availableForWrite(HardwareSerial_t *ser)
{
	return ((tx_buffer_index_t)(SERIAL_TX_BUFFER_SIZE + ser->_tx_buffer_head - ser->_tx_buffer_tail)) % SERIAL_TX_BUFFER_SIZE;
}
size_t HardwareSerial_write(HardwareSerial_t *ser,uint8_t p_tr)
{
	tx_buffer_index_t i;
	//sbool state = 0;
	unsigned char c = 0;

	//state = ser->_written;
	
	i = (ser->_tx_buffer_head + 1) % SERIAL_TX_BUFFER_SIZE;

	
	
	 while (i == ser->_tx_buffer_tail)//����������,�ȴ��жϷ���,������bug,�������ͼĴ���û����ʱ,���ˣ��ͻ�ͣ����,
	{

	}

	ser->_tx_buffer[ser->_tx_buffer_head] = p_tr;
  ser->_tx_buffer_head = i;
	
	
	if (ser->_written == false)
	{
			c = ser->_tx_buffer[ser->_tx_buffer_tail];
			ser->_tx_buffer_tail = (ser->_tx_buffer_tail + 1) % SERIAL_TX_BUFFER_SIZE;
		
		
			//EA = 0;
			ser->hard_send_cb(ser,c);
			ser->_written = true;
			//EA = 1;
		
			return 1;
	}
	
	return 1;
}
void HardwareSerial_Init(HardwareSerial_t *ser,hard_msg_cb basic_cb,hard_msg_cb send)
{
	
		ser->_rx_buffer_head = 0;
    ser->_rx_buffer_tail = 0;
    ser->_tx_buffer_head = 0;
    ser->_tx_buffer_tail = 0;
		ser->init_end_cb = basic_cb;
		ser->hard_send_cb = send;
		ser->_written = false;
}
void HardwareSerial_begin(HardwareSerial_t *ser)
{
	ser->init_end_cb(ser,HSER_MSG_INIT);
}
void HardwareSerial_end(HardwareSerial_t *ser)
{
	ser->init_end_cb(ser,HSER_MSG_END);
}